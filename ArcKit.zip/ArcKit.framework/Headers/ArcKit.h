//
//  ArcKit.h
//  ArcKit
//
//  Created by Matt Greenfield on 2/07/17.
//  Copyright © 2017 Big Paua. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ArcKit.
FOUNDATION_EXPORT double ArcKitVersionNumber;

//! Project version string for ArcKit.
FOUNDATION_EXPORT const unsigned char ArcKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ArcKit/PublicHeader.h>


